/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "string.h"
#include <stdio.h>
#include "math.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
DMA_HandleTypeDef hdma_tim1_ch1;

UART_HandleTypeDef huart2;

/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for Knob_Button */
osThreadId_t Knob_ButtonHandle;
const osThreadAttr_t Knob_Button_attributes = {
  .name = "Knob_Button",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for humidityPWM */
osThreadId_t humidityPWMHandle;
const osThreadAttr_t humidityPWM_attributes = {
  .name = "humidityPWM",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for pressurePWM */
osThreadId_t pressurePWMHandle;
const osThreadAttr_t pressurePWM_attributes = {
  .name = "pressurePWM",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* USER CODE BEGIN PV */

enum mode {Off = 0, On, Settings}; // Device Modes
enum mode deviceMode;
enum state {LowPressure = 0, HighPressure, Rate, Humidity}; // Device settings states
enum state deviceSetting;

volatile uint16_t pressurePWM = 0;
volatile uint16_t humidityPWM = 0;

uint8_t flag=0;
uint8_t humidFlag=0;
uint8_t rateFlag=0;
uint8_t setPointsFlag = 0;

uint8_t buttonDown = 0;
uint8_t count = 0;

uint32_t counter = 0;
uint16_t countInt = 0;
uint16_t position = 0;
uint16_t positionHumid = 0;
uint16_t prevPosition = 0;

uint16_t lowPressureDutyCycle = 0;	// %
uint16_t highPressureDutyCycle = 0;	// %
uint16_t humidityDutyCycle = 0;	// %
uint16_t breathRate = 0;	// Breaths/minute
uint16_t pressurePeriod = 100;	// ms
uint16_t humidityPeriod = 100;	// ms

uint8_t dataRead[10];
uint8_t dataWrite[10];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM2_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM1_Init(void);
static void MX_I2C1_Init(void);
void StartDefaultTask(void *argument);
void Pressed_Knob_Button(void *argument);
void humidityRTOS(void *argument);
void pressureRTOS(void *argument);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	// The rotary encoder increments by 4 with each click that the knob turns
	// The value is divided by 4 to obtain an increment of 1
	// The if statements limits the rotary encoder values so that it is between 0 and 100
	// If the current setting state is rate, the rotary encoder values is limited between 8 and 25
	// If the current setting state is humidity, the increments is set to 5

	if(deviceSetting == Humidity && humidFlag == 0)
	{
		__HAL_TIM_SET_COUNTER(htim, 0);
		humidFlag = 1;
	}

	if(deviceSetting == Rate && rateFlag == 0)
	{
		__HAL_TIM_SET_COUNTER(htim, 32);
		rateFlag = 1;
	}

	if(counter > 400 && counter < 5000)			// If the rotary encoder value is larger than 400,
	{											// and smaller than 5000 the rotary encoder value is set at 400
		__HAL_TIM_SET_COUNTER(htim, 400);		// This limits the rotary encoder value so that it is between 0 and 100
		counter = __HAL_TIM_GET_COUNTER(htim);
		countInt = (int16_t)counter;
		position = countInt/4;
		positionHumid = position*5;

	}
	else if(counter > 5000)						// If the rotary encoder value is larger than 5000 the rotary encoder value is set at 0
	{											// This happens when the rotary encoder goes past 0 when turning the knob in the anti-clockwise
		__HAL_TIM_SET_COUNTER(htim, 0); 		// direction, it auto-reloads and the value is then 65535
		counter = __HAL_TIM_GET_COUNTER(htim);
		countInt = 0;
		position = 0;
		positionHumid = position*5;
	}
	else										// If the rotary encoder value is between 0 and 400, the position is set to
	{											// position = countInt/4 and positionHumid = position*5
		counter = __HAL_TIM_GET_COUNTER(htim);
		countInt = (int16_t)counter;
		position = countInt/4;
		positionHumid = position*5;
	}

	if(positionHumid > 100 && positionHumid < 1250 && deviceSetting == Humidity)	// If the current setting state is Humidity
	{																				// and the positionHumid is larger than 100
		__HAL_TIM_SET_COUNTER(htim, 80);											// the rotary encoder value is set to 80
		counter = __HAL_TIM_GET_COUNTER(htim);										// (so that positionHumid is 80/4*5 = 100)
		countInt = (int16_t)counter;
		position = countInt/4;
		positionHumid = position*5;
	}

	if(position > 25 && position < 1250 && deviceSetting == Rate)	// If the current setting state is Rate and the position is
	{																// larger than 25 the rotary encoder value is set to 100
		__HAL_TIM_SET_COUNTER(htim, 100);							// (so that position is 100/4 = 25)
		counter = __HAL_TIM_GET_COUNTER(htim);
		countInt = (int16_t)counter;
		position = countInt/4;
	}

	if(position < 8 && deviceSetting == Rate)	// If the current state is Rate and the position is smaller than 8
	{											// The rotary encoder value is set to 32 (so that position is 32/4 = 8)
		__HAL_TIM_SET_COUNTER(htim, 32);
		counter = __HAL_TIM_GET_COUNTER(htim);
		countInt = (int16_t)counter;
		position = countInt/4;
	}
}

#define MAX_LED 6 // There are 6 WS2812B LEDs
#define USE_BRIGHTNESS 1 // If we would like to change the brightness of the LEDs this is set to 1

uint8_t LED_Data[MAX_LED][4];
uint8_t LED_Mod[MAX_LED][4];

int dataSentFlag=0;

void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim)
{
	HAL_TIM_PWM_Stop_DMA(&htim1, TIM_CHANNEL_1);
	dataSentFlag=1;
}

void setLED (int LEDnum, int Red, int Green, int Blue) // Function to set the color of the LED
{
	LED_Data[LEDnum][0] = LEDnum;
	LED_Data[LEDnum][1] = Green;
	LED_Data[LEDnum][2] = Red;
	LED_Data[LEDnum][3] = Blue;
}

#define PI 3.14159265

void setBrightness (int brightness, int LEDnum) // Set the brightness of the LEDs
{												// The brightness values ranges from 0 to 45
#if USE_BRIGHTNESS
	if (brightness > 45) brightness = 45;
	for (int i=0; i<MAX_LED; i++)
	{
		LED_Mod[LEDnum][0] = LED_Data[LEDnum][0];
		for (int j=1; j<4; j++)
		{
			float angle = 90-brightness;  // in degrees
			angle = angle*PI / 180;  // in radians
			LED_Mod[LEDnum][j] = (LED_Data[LEDnum][j])/(tan(angle));
		}
	}
#endif
}

uint16_t pwmData[(24*MAX_LED)+50];

void sendRGB (void)		// To send the color and brightness data to the RGB
{
	uint32_t indx=0;
	uint32_t color;

	for (int i= 0; i<MAX_LED; i++)
	{
#if USE_BRIGHTNESS
		color = ((LED_Mod[i][1]<<16) | (LED_Mod[i][2]<<8) | (LED_Mod[i][3]));
#else
		color = ((LED_Data[i][1]<<16) | (LED_Data[i][2]<<8) | (LED_Data[i][3]));
#endif
		for (int i=23; i>=0; i--)
		{
			if (color&(1<<i))		// From the datasheet the period of the 1 code of the RGB is 1.25us. This gives a frequency of 800kHz.
			{						// The time high is 0.8us which is 64% (about 2/3) of the duty cycle and time low is 0.4us which is 34% (about 1/3)
									// The clock is running at 72MHz which means that the counter period is 90-1 (72M/90=800k)
				pwmData[indx] = 60; // 2/3 of 90
			}
			else pwmData[indx] = 30;  // 1/3 of 90
			indx++;
		}
	}

	for (int i=0; i<50; i++)
	{
		pwmData[indx] = 0;
		indx++;
	}

	HAL_TIM_PWM_Start_DMA(&htim1, TIM_CHANNEL_1, (uint32_t *)pwmData, indx);
	while (!dataSentFlag){};
	dataSentFlag = 0;
}

void resetLED (void)
{
	for (int i=0; i<MAX_LED; i++) // To reset all LEDs
	{
		LED_Data[i][0] = i;
		LED_Data[i][1] = 0;
		LED_Data[i][2] = 0;
		LED_Data[i][3] = 0;
	}
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
 	deviceMode = Off;
	deviceSetting = LowPressure;
	lowPressureDutyCycle = 0;
	highPressureDutyCycle = 0;
	humidityDutyCycle = 0;
	breathRate = 0;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  MX_DMA_Init();
  MX_TIM1_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */

  HAL_TIM_Encoder_Start_IT(&htim2, TIM_CHANNEL_ALL);

  for (int i = 0;i<10; i++)
  {
 	 dataWrite[i]=i*10+10;
  }

  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* creation of Knob_Button */
  Knob_ButtonHandle = osThreadNew(Pressed_Knob_Button, NULL, &Knob_Button_attributes);

  /* creation of humidityPWM */
  humidityPWMHandle = osThreadNew(humidityRTOS, NULL, &humidityPWM_attributes);

  /* creation of pressurePWM */
  pressurePWMHandle = osThreadNew(pressureRTOS, NULL, &pressurePWM_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if(1==flag) // If the rotary button was pressed
	  {
		  HAL_GPIO_TogglePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin); // Toggle the Green Run LED
		  flag=0;
	  }
	  HAL_I2C_Master_Transmit(&hi2c1, 0x57<<1, &dataWrite, 1, 100);
	  HAL_I2C_Master_Receive(&hi2c1, 0x57<<1, &dataRead, 1, 100);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 72;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 400000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 90-1;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 65535;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 0;
  sConfig.IC2Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA2_Stream1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream1_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream1_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LED_GREEN_Pin|LED_Status_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, Humidity_PWM_Pin|Pressure_PWM_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : LED_GREEN_Pin LED_Status_Pin */
  GPIO_InitStruct.Pin = LED_GREEN_Pin|LED_Status_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : Knob_Button_Encoder_Pin */
  GPIO_InitStruct.Pin = Knob_Button_Encoder_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(Knob_Button_Encoder_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : Humidity_PWM_Pin Pressure_PWM_Pin */
  GPIO_InitStruct.Pin = Humidity_PWM_Pin|Pressure_PWM_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	flag=1;
}
/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN 5 */
  /* Infinite loop */

	for(;;)
	{
		while (1)
		{
			switch(deviceMode)
			{
		  		case Off:		// If the device is in OFF mode
		  		{
		  			HAL_UART_Transmit(&huart2, "\r\nOFF\r\n", 7, HAL_MAX_DELAY); // The attached terminal will show "OFF"

		  			resetLED();
		  			setBrightness(30,0);
		  			setBrightness(30,1);
		  			setBrightness(30,2);
		  			setBrightness(30,3);
		  			setBrightness(30,4);
		  			setBrightness(30,5);
		  			sendRGB();

		  			setLED(0,255, 0, 0); 	// LED 0 will show a red light which indicates that the device is off.
		  			setBrightness(30,0);
		  			sendRGB();

		  			while (deviceMode == Off)
		  			{
		  				osDelay(1);
		  			}
		  		}break;
		  		case On:		// If the device is in ON mode
		  		{
		  			setLED(0, 0, 255, 0); // LED 0 will show a green light which indicates that the device is on.
		  			setBrightness(30,0);
		  			sendRGB();

		  			HAL_UART_Transmit(&huart2, "\r\nON\r\n", 6, HAL_MAX_DELAY); // The attached terminal will show "ON" to
		  																		// indicate that the device is on.
		  			if (setPointsFlag == 0)			// If the device is reset, no valid set points are stored.
		  			{
		  				setLED(5, 255, 153, 0);		// Therefore LED 5 will show a yellow light which indicates
		  				setBrightness(30,5);		// that no valid set points are stored on the device.
		  				sendRGB();					// The attached terminal will also show that no valid set points are stored on the device.
		  				HAL_UART_Transmit(&huart2, "\r\nNo valid set points are stored\r\n", 34, HAL_MAX_DELAY);
		  			}
		  			else							// If the device has valid set points are stored
		  			{
		  				setLED(5,0, 0, 0);			// LED 5 will have no color
		  				setBrightness(30,5);
		  				sendRGB();
		  			}

		  			while (deviceMode == On)
		  			{
		  				osDelay(1);
		  			}

		  		}break;
		  		case Settings: // If the device is in Settings mode
		  		{
		  			HAL_UART_Transmit(&huart2, "\r\nSettings\r\n", 12, HAL_MAX_DELAY);  // The attached terminal will show "Settings" to indicate that the device is in settings mode.

		  			setLED(0, 255, 128, 0);		// LED 0 will show a yellow light to indicate that the device is in Settings mode.
		  			setLED(1, 0, 0, 0);			// LEDs 1, 2 and 3 are set that they have no color.
		  			setLED(2, 0, 0, 0);
		  			setLED(3, 0, 0, 0);
		  			setBrightness(30,0);
		  			setBrightness(30,1);
		  			setBrightness(30,2);
		  			setBrightness(30,3);
		  			sendRGB();
		  			while (deviceMode == Settings)
		  			{
		  				switch(deviceSetting)
		  				{
				  	  		case LowPressure:	// If the device is in Settings mode in the state Low Pressure
				  	  	  	{
				  	  	  		setLED(3, 0, 0, 0);		// LED 3 will have no color.
				  	  	  		setLED(1, 0, 0, 255);	// LED 1 will have a blue color to indicate that the
				  	  	  		setBrightness(30,3);	// low Pressure point is being set.
				  	  	  		setBrightness(30,1);
				  	  	  		sendRGB(); // Send the color and brightness to the RGB
				  	  	  		HAL_UART_Transmit(&huart2, "Input Low Pressure point:\r\n", 27, HAL_MAX_DELAY);  	// The attached terminal will ask to input the low pressure point
				  	  	  		while (deviceSetting == LowPressure && deviceMode == Settings)
				  	  	  		{
				  	  	  			if(position >= 0 && position <= 100)
				  	  	  			{
				  	  	  				if (prevPosition != position) // The attached terminal will continuously show the value of the rotary knob if it is changed
				  	  	  				{
				  	  	  					char knobValue[32];
				  	  	  					sprintf(knobValue,"%d",position);
				  	  	  					HAL_UART_Transmit(&huart2, knobValue, strlen((char*)knobValue), HAL_MAX_DELAY);
				  	  	  					HAL_UART_Transmit(&huart2, " ", 2, HAL_MAX_DELAY);
				  	  	  					setLED(4, 255, 255, 255);
				  	  	  					setBrightness(position*45/100,4);	// The brightness of LED 4 will change as the value of the rotary knob changes
				  	  	  					sendRGB();	// Send the color and brightness to the RGB
				  	  	  				}
				  	  	  				prevPosition = position;
				  	  	  				osDelay(1);
				  	  	  			}
				  	  	  		}
				  	  	  	}break;
				  	  		case HighPressure:	// If the device is in Settings mode in the state High Pressure
				  	  		{
				  	  			setLED(1, 255, 0, 0);	// LED 1 will have a red color to indicate that the high Pressure point is being set.
				  	  			setBrightness(30,1);
				  	  			sendRGB(); // Send the color and brightness to the RGB
				  	  			HAL_UART_Transmit(&huart2, "Input High Pressure point:\r\n", 28, HAL_MAX_DELAY); // The attached terminal will ask to input the high pressure point
				  	  			while (deviceSetting == HighPressure && deviceMode == Settings)
				  	  			{
				  	  				if (position >= 0 && position <= 100)
				  	  				{
				  	  					if (prevPosition != position) // The attached terminal will continuously show the value of the rotary knob if it is changed
				  	  					{
				  	  						char knobValue[32];
				  	  						sprintf(knobValue,"%d",position);
				  	  						HAL_UART_Transmit(&huart2, knobValue, strlen((char*)knobValue), HAL_MAX_DELAY);
				  	  						HAL_UART_Transmit(&huart2, " ", 2, HAL_MAX_DELAY);
				  	  						setLED(4, 255, 255, 255);
				  	  						setBrightness(position*45/100,4); // The brightness of LED 4 will change as the value of the rotary knob changes
				  	  						sendRGB(); // Send the color and brightness to the RGB
				  	  					}
				  	  					prevPosition = position;
				  	  					osDelay(1);
				  	  				}
				  	  			}
				  	  		}break;
				  	  		case Rate: // If the device is in Settings mode in the state Rate
				  	  		{
				  	  			setLED(1, 0, 0, 0);		// LED 1 will show no color
				  	  			setLED(2, 0, 255, 0);	// LED 2 will show a green color.
				  	  			setBrightness(30,1);
				  	  			setBrightness(30,2);
				  	  			sendRGB(); // Send the color and brightness to the RGB
				  	  			HAL_UART_Transmit(&huart2, "Input Breath Rate:\r\n", 20, HAL_MAX_DELAY); // The attached terminal will ask to input the breathing rate
				  	  			while (deviceSetting == Rate && deviceMode == Settings)
				  	  			{
				  	  				if (position >= 8 && position <= 25)
				  	  				{
				  	  					if (prevPosition != position) // The attached terminal will continuously show the value of the rotary knob if it is changed
				  	  					{
				  	  						char knobValue[32];
				  	  						sprintf(knobValue,"%d",position);
				  	  						HAL_UART_Transmit(&huart2, knobValue, strlen((char*)knobValue), HAL_MAX_DELAY);
				  	  						HAL_UART_Transmit(&huart2, " ", 2, HAL_MAX_DELAY);
				  	  						setLED(4, 255, 255, 255);
				  	  						setBrightness(position*45/17-21.12,4); // The brightness of LED 4 will change as the value of the rotary knob changes
				  	  						sendRGB(); // Send the color and brightness to the RGB
				  	  					}
				  	  					prevPosition = position;
				  	  					osDelay(1);
				  	  				}
				  	  			}
				  	  			rateFlag = 0;
				  	  		}
				  	  		case Humidity: // If the device is in Settings mode in the state Humidity
				  	  		{
				  	  			setLED(2, 0, 0, 0); // LED 2 will show no color
				  	  			setLED(3, 255, 0, 255); // LED 3 will show a magenta color
				  	  			setBrightness(30,2);
				  	  			setBrightness(30,3);
				  	  			sendRGB(); // Send the color and brightness to the RGB
				  	  			HAL_UART_Transmit(&huart2, "Input Humidification level:\r\n", 29, HAL_MAX_DELAY); // The attached terminal will ask to input the humidification level
				  	  			while (deviceSetting == Humidity && deviceMode == Settings)
				  	  			{
				  	  				if (positionHumid >= 0 && positionHumid <= 100)
				  	  				{
				  	  					if (prevPosition != positionHumid) // The attached terminal will continuously show the value of the rotary knob if it is changed
				  	  					{
				  	  						char knobValue[32];
				  	  						sprintf(knobValue,"%d",positionHumid);
				  	  						HAL_UART_Transmit(&huart2, knobValue, strlen((char*)knobValue), HAL_MAX_DELAY);
				  	  						HAL_UART_Transmit(&huart2, " ", 2, HAL_MAX_DELAY);
				  	  						setLED(4, 255, 255, 255);
				  	  						setBrightness(positionHumid*45/100,4); // The brightness of LED 4 will change as the value of the rotary knob changes
				  	  						sendRGB(); // Send the color and brightness to the RGB
				  	  					}
				  	  					prevPosition = positionHumid;
				  	  					osDelay(1);
				  	  				}
				  	  			}
				  	  			humidFlag = 0;
				  	  			setPointsFlag = 1; // Valid set points are stored on the device.
				  	  			setLED(5, 0, 0, 0); // LED 5 clears which means that there are valid set points stored on the device.
				  	  			setBrightness(30,5);
				  	  			sendRGB();

				  	  		}break;
				  	  		default:
							{
								deviceSetting = LowPressure;
							}
		  				}
		  			}break;
		  	  	  	default:
		  	  	  	{
		  	  	  		deviceMode = On;
		  	  	  	}
		  		}
			}
		}
	}
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_Pressed_Knob_Button */
/**
* @brief Function implementing the Knob_Button thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Pressed_Knob_Button */
void Pressed_Knob_Button(void *argument)
{
  /* USER CODE BEGIN Pressed_Knob_Button */
  /* Infinite loop */
  for(;;)
  {
 	  if(flag == 1) // If the button is pressed.
	  {
		  HAL_GPIO_TogglePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin);
		  flag=0;

		  if(buttonDown==0) // If the button is hold down.
		  {
			  count = 0;
			  buttonDown = 1;
			  while(flag == 0)
			  {
				  osDelay(100);
				  count++;  // This determines the time the button is hold down (each count is 100ms)
				  if(count == 30 || count == 20 || count == 10) // LED 4 will blink every time that a second passes by until 3 seconds is reached
				  {
					  setLED(4, 255, 0, 0);
					  setBrightness(30,4);
					  sendRGB();
					  osDelay(100);
					  setLED(4, 0, 0, 0);
					  setBrightness(30,4);
					  sendRGB();
				  }
			  }
		  }
		  else // If the button is released
		  {
			  setLED(4, 0, 0, 0);
			  setBrightness(30,4);
			  sendRGB();
			  buttonDown = 0;

			  int difference = count;

			  if (difference>=30) 		// Time the button was hold down more or equal than 3s
			  {
				  if (deviceMode==Off)
				  {
					  deviceMode = On;
				  }
				  else
				  {
					  deviceMode = Off;
				  }
			  }
			  else if (difference>=10) 	// Time the button was hold down more or equal than 1s
			  {
				  if (deviceMode == Settings)
				  {
					  deviceMode = On;
				  }
				  else if (deviceMode == On)
				  {
					  deviceMode = Settings;
					  deviceSetting = LowPressure;
				  }
			  }
			  else 						// Time the button hold down less than 1s
			  {
				  if (deviceMode == Settings)
				  {
					  char knobValue[32];
					  if (deviceSetting == Humidity)
					  {
						  sprintf(knobValue,"%d",positionHumid);
					  }
					  else
					  {
						  sprintf(knobValue,"%d",position);
					  }

					  if (deviceSetting == LowPressure)
					  {
						  HAL_UART_Transmit(&huart2, "\r\nLow Pressure is set at: ", 26, HAL_MAX_DELAY);
					  }
					  else if (deviceSetting == HighPressure)
					  {
						  HAL_UART_Transmit(&huart2, "\r\nHigh Pressure is set at: ", 27, HAL_MAX_DELAY);
					  }
					  else if (deviceSetting == Rate)
					  {
						  HAL_UART_Transmit(&huart2, "\r\nBreathrate is set at: ", 24, HAL_MAX_DELAY);
					  }
					  else if (deviceSetting == Humidity)
					  {
						  HAL_UART_Transmit(&huart2, "\r\nHumidification is set at: ", 28, HAL_MAX_DELAY);
					  }
					  HAL_UART_Transmit(&huart2, knobValue, strlen((char*)knobValue), HAL_MAX_DELAY); // The knob value that was set at each parameter is displayed in the terminal
					  HAL_UART_Transmit(&huart2, "\r\n\r\n", 4, HAL_MAX_DELAY);

					  switch(deviceSetting) // If the button was pressed less than 1s the device setting state changes
					  {
				 	  	  case LowPressure:
				 	  	  {
				 	  		  lowPressureDutyCycle = position;
				 	  		  deviceSetting = HighPressure;
				 	  	  }break;
				 	  	  case HighPressure:
				 	  	  {
				 	  		  highPressureDutyCycle = position;
				 	  		  deviceSetting = Rate;
				 	  	  }break;
				 	  	  case Rate:
				 	  	  {
				 	  		  breathRate = position;
				 	  		  deviceSetting = Humidity;
				 	  	  }break;
				 	  	  case Humidity:
				 	  	  {
				 	  		  humidityDutyCycle = positionHumid;
				 	  		  deviceSetting = LowPressure;
				 	  	  }break;
				 	  	  default:
				 	  	  {
				 	  		  deviceSetting = LowPressure;
				 	  	  }
					  }
				  }
			  }
		  }
	  }
  }

  /* USER CODE END Pressed_Knob_Button */
}

/* USER CODE BEGIN Header_humidityRTOS */
/**
* @brief Function implementing the humidityPWM thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_humidityRTOS */
void humidityRTOS(void *argument)
{
  /* USER CODE BEGIN humidityRTOS */
  /* Infinite loop */
  for(;;)
  {
	  if (deviceMode == On && setPointsFlag == 1) // If the device is On and alid set points are stored on the device.
	  {
		  setLED(3, 0, 0, 255); // The color of the LED which indicates the PWM of the humidity is blue
		  setBrightness(30,3);
		  sendRGB();
		  humidityPWM = 1;
		  HAL_GPIO_TogglePin(Humidity_PWM_GPIO_Port, Humidity_PWM_Pin);	// The signal is sent to the pin PA9
		  osDelay(humidityPeriod*humidityDutyCycle/100);	// This delay keeps the signal high for the time of the humidityPeriod*humiditydutyCycle

		  setLED(3, 0, 0, 0); // The color of the LED is cleared
		  setBrightness(30,3);
		  sendRGB();
		  humidityPWM = 0;
		  HAL_GPIO_TogglePin(Humidity_PWM_GPIO_Port, Humidity_PWM_Pin); // The signal is sent to the pin PA9
		  osDelay(humidityPeriod-humidityPeriod*humidityDutyCycle/100); // This delay keeps the signal low for the rest of the humidityPeriod time
	  }
  }
  /* USER CODE END humidityRTOS */
}

/* USER CODE BEGIN Header_pressureRTOS */
/**
* @brief Function implementing the pressurePWM thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_pressureRTOS */
void pressureRTOS(void *argument)
{
  /* USER CODE BEGIN pressureRTOS */
  /* Infinite loop */
	for(;;)
	{
		if (deviceMode == On && setPointsFlag == 1) // If the device is On and alid set points are stored on the device.
		{
			int n = 60/breathRate*1000/2;
			n = n/pressurePeriod;

			for(int i = n; i>=0 ;i--)
			{
			  	if (deviceMode == Settings || deviceMode == Off) // If the device mode is changed to Settings or Off, the program exits the for loop
			  	{
			  		break;
			  	}

				setLED(2, 255, 153, 0); // Here LED 1 with a yellow color will show the breathing out
				setBrightness(i*2,2);  	// The brightness will decrease as the patient breathes out
				setLED(1, 255, 0, 0);
				setBrightness(30,1);
				sendRGB();
				pressurePWM = 1;
				HAL_GPIO_TogglePin(Pressure_PWM_GPIO_Port, Pressure_PWM_Pin); // The signal is sent to the pin PA10
			  	osDelay(pressurePeriod*lowPressureDutyCycle/100); // This delay keeps the signal high for the time of the pressurePeriod*lowPressureDutyCycle

			  	setLED(1, 0, 0, 0);
			  	setBrightness(30,1);
			  	sendRGB();
			  	pressurePWM = 0;
			  	HAL_GPIO_TogglePin(Pressure_PWM_GPIO_Port, Pressure_PWM_Pin); // The signal is sent to the pin PA10
			  	osDelay(pressurePeriod-pressurePeriod*lowPressureDutyCycle/100); // This delay keeps the signal low for the rest of the pressurePeriod time
			}

			for(int i = 0; i<n; i++)
			{
				if (deviceMode == Settings || deviceMode == Off)
				{
					break;
				}
				setLED(2, 0, 0, 255); // Here LED 1 with a blue color will show the breathing in
				setBrightness(i*2,2); // The brightness will decrease as the patient breathes in
				setLED(1, 255, 0, 0);
				setBrightness(30,1);
				sendRGB();
				pressurePWM = 1;
				HAL_GPIO_TogglePin(Pressure_PWM_GPIO_Port, Pressure_PWM_Pin); // The signal is sent to the pin PA10
				osDelay(pressurePeriod*highPressureDutyCycle/100); // This delay keeps the signal high for the time of the pressurePeriod*highPressureDutyCycle

				setLED(1, 0, 0, 0);
				setBrightness(30,1);
				sendRGB();
				pressurePWM = 0;
				HAL_GPIO_TogglePin(Pressure_PWM_GPIO_Port, Pressure_PWM_Pin); // The signal is sent to the pin PA10
				osDelay(pressurePeriod-pressurePeriod*highPressureDutyCycle/100); // This delay keeps the signal low for the rest of the pressurePeriod time
			}
		  }
	  }
  /* USER CODE END pressureRTOS */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM10 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM10) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
